
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { GameView, GameMode, Question, PlayerStats, LevelConfig, ChallengeStage, MissedQuestion } from './types';
import { generateLevelQuestions, generateChallengeQuestions, generateRecoveryQuestions } from './services/geminiService';
import { playCorrectSound, playWrongSound, playVictorySound, playTimeoutSound, playGameOverSound, initAudio, toggleMute, playClickSound, playLiftoffSound } from './services/audioService';
import { PlanetIcon, RobotMascot, Star, SpaceBackground, HealthHeart, TrophyIcon, ParticleBurst, FlagIcon } from './components/Visuals';
import { Play, RotateCcw, Home, Star as StarIcon, Trophy, Volume2, VolumeX, Timer, BookOpen, Rocket, Heart, AlertTriangle, ArrowRight, Award, Stethoscope, User, Edit3 } from 'lucide-react';

const PLANETS: LevelConfig[] = [
  { 
    tableNumber: 0, 
    planetName: "Cero-Z", 
    planetColor: "#94a3b8",
    missionTitle: "El Vacío Oscuro",
    missionDescription: "¡Alerta! Un agujero negro está absorbiendo la energía del sector. Cualquier cosa que lances al núcleo se multiplica por cero y desaparece. ¡Calcula cuánta energía se pierde!",
    aiContext: "agujeros negros, vacío, nada, desaparecer, cero",
    missionItem: "unidades de energía perdidas"
  },
  { 
    tableNumber: 1, 
    planetName: "Uno-Prime", 
    planetColor: "#f87171",
    missionTitle: "La Soledad del Capitán",
    missionDescription: "Estamos enviando cápsulas de rescate a pilotos perdidos. Cada cápsula tiene espacio para exactamente 1 piloto. Calcula cuántos pilotos podemos salvar con nuestras cápsulas.",
    aiContext: "cápsulas individuales, un solo piloto, unidad, solitario",
    missionItem: "pilotos rescatados"
  },
  { 
    tableNumber: 2, 
    planetName: "Duo-Terra", 
    planetColor: "#fb923c",
    missionTitle: "El Planeta Gemelo",
    missionDescription: "La gravedad aquí es inestable. Los exploradores necesitan 2 botas magnéticas cada uno para poder caminar por el techo de las cuevas de cristal.",
    aiContext: "pares de botas, gemelos, dos motores, binario",
    missionItem: "botas magnéticas"
  },
  { 
    tableNumber: 3, 
    planetName: "Tri-Star", 
    planetColor: "#facc15",
    missionTitle: "Energía Triangular",
    missionDescription: "Los generadores antiguos tienen forma de pirámide. Necesitamos colocar 3 celdas de energía en las esquinas de cada generador para reactivarlos.",
    aiContext: "triángulos, tres esquinas, triciclos, pirámides",
    missionItem: "celdas de energía"
  },
  { 
    tableNumber: 4, 
    planetName: "Cuadra-X", 
    planetColor: "#4ade80",
    missionTitle: "Operación: Todoterreno",
    missionDescription: "Los Rovers de exploración han perdido sus ruedas en una tormenta de arena. Tu misión es fabricar ruedas nuevas. Cada vehículo necesita 4 ruedas para moverse.",
    aiContext: "coches, cuatro ruedas, cuadrados, mesas, patas",
    missionItem: "ruedas de rover"
  },
  { 
    tableNumber: 5, 
    planetName: "Cinco-V", 
    planetColor: "#2dd4bf",
    missionTitle: "El Saludo Alienígena",
    missionDescription: "Los habitantes de este planeta son muy amistosos. Tienen 5 manos robóticas cada uno. ¡Calcula cuántas manos nos están saludando!",
    aiContext: "manos, cinco dedos, estrellas de mar, pentágonos",
    missionItem: "manos robóticas"
  },
  { 
    tableNumber: 6, 
    planetName: "Hexa-Moon", 
    planetColor: "#38bdf8",
    missionTitle: "La Colmena de Carbono",
    missionDescription: "Las abejas mecánicas almacenan combustible de plasma. Cada celda del panal tiene 6 lados blindados que debemos pulir para evitar fugas.",
    aiContext: "panales, abejas, hexágonos, seis lados, insectos",
    missionItem: "lados blindados"
  },
  { 
    tableNumber: 7, 
    planetName: "Septim-7", 
    planetColor: "#818cf8",
    missionTitle: "Cargamento Pesado",
    missionDescription: "Estamos minando rocas de meteorito muy densas. Cada roca de 'Septimio' pesa exactamente 7 kilogramos. Calcula el peso total para no sobrecargar la nave.",
    aiContext: "rocas pesadas, 7 kg, minería espacial, siete colores",
    missionItem: "kilogramos de peso"
  },
  { 
    tableNumber: 8, 
    planetName: "Octo-Belt", 
    planetColor: "#c084fc",
    missionTitle: "La Estación Arácnida",
    missionDescription: "Los robots araña se encargan del mantenimiento exterior. Tienen 8 patas magnéticas para trepar por el casco de la nave. ¿Cuántas patas hay en total?",
    aiContext: "arañas, pulpos, ocho patas, octágonos, tentáculos",
    missionItem: "patas de araña"
  },
  { 
    tableNumber: 9, 
    planetName: "Nove-Nebula", 
    planetColor: "#f472b6",
    missionTitle: "Resistencia Gatuna",
    missionDescription: "La niebla tóxica es peligrosa. Necesitamos baterías especiales que duran 9 horas cada una para mantener los sistemas de soporte vital funcionando.",
    aiContext: "baterías, nueve vidas, grupos de nueve, nubes",
    missionItem: "horas de energía"
  },
  { 
    tableNumber: 99, 
    planetName: "Supernova-X", 
    planetColor: "#ec4899",
    missionTitle: "El Gran Torneo Galáctico",
    missionDescription: "¡La prueba definitiva! Has viajado por todo el sistema solar. Ahora debes demostrar que dominas TODAS las tablas de multiplicar para convertirte en el Guardián del Universo. ¡Preguntas mezcladas de alto nivel!",
    aiContext: "galaxia, universo, mezcla de retos, examen final, héroe",
    missionItem: "medallas de valor"
  },
];

const CHALLENGE_STAGES: ChallengeStage[] = [
  { id: 'c1', name: "Cadete Espacial", allowedTables: [0, 1, 2, 3], questionCount: 10, timeLimit: 60, trophyReward: 'trophy_bronze', description: "Prueba básica: Tablas del 0 al 3" },
  { id: 'c2', name: "Piloto de Combate", allowedTables: [0, 1, 2, 3, 4, 5, 6], questionCount: 15, timeLimit: 55, trophyReward: 'trophy_silver', description: "Intermedio: Tablas del 0 al 6" },
  { id: 'c3', name: "Comandante Estelar", allowedTables: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], questionCount: 20, timeLimit: 50, trophyReward: 'trophy_gold', description: "Experto: ¡Todas las tablas!" },
  { id: 'c4', name: "Leyenda Galáctica", allowedTables: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], questionCount: 30, timeLimit: 40, trophyReward: 'trophy_diamond', description: "Velocidad Extrema: Supervivencia" }
];

const MAX_HEALTH = 3;

interface Burst {
  id: number;
  x: number;
  y: number;
  color: string;
}

// Fisher-Yates Shuffle for ensuring random position of answers in UI
function shuffleOptions<T>(array: T[]): T[] {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
}

export default function App() {
  // State
  const [view, setView] = useState<GameView>(GameView.MENU);
  const [gameMode, setGameMode] = useState<GameMode>(GameMode.MISSION);
  const [selectedLevel, setSelectedLevel] = useState<LevelConfig | null>(null);
  const [currentChallengeStageIndex, setCurrentChallengeStageIndex] = useState(0);

  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [health, setHealth] = useState(MAX_HEALTH);
  const [shakeHealth, setShakeHealth] = useState(false);
  const [correctCount, setCorrectCount] = useState(0); // For practice stats
  const [stats, setStats] = useState<PlayerStats>({ playerName: "", stars: {}, totalXp: 0, trophies: [], missedQuestions: [] });
  
  // Name Input State
  const [showNameInput, setShowNameInput] = useState(false);
  const [tempName, setTempName] = useState("");

  // Feedback States
  const [feedback, setFeedback] = useState<'none' | 'correct' | 'wrong' | 'timeout'>('none');
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [bursts, setBursts] = useState<Burst[]>([]);
  const [transitionState, setTransitionState] = useState<'in' | 'out'>('in');
  
  const [loadingText, setLoadingText] = useState("Cargando Motores...");
  const [isMuted, setIsMuted] = useState(false);
  const [timeLeft, setTimeLeft] = useState(60);
  const [briefingShown, setBriefingShown] = useState(false);
  const [isLaunching, setIsLaunching] = useState(false);

  const robotRef = useRef<HTMLDivElement>(null);

  // Load stats from local storage on mount
  useEffect(() => {
    const saved = localStorage.getItem('misionMultiplicacionStats');
    if (saved) {
      const parsed = JSON.parse(saved);
      // Migration for old saves
      if (!parsed.trophies) parsed.trophies = [];
      if (!parsed.missedQuestions) parsed.missedQuestions = [];
      if (!parsed.playerName) parsed.playerName = ""; 
      
      setStats(parsed);
      
      // If no name is set, show input
      if (!parsed.playerName) {
          setShowNameInput(true);
      }
    } else {
        // First time playing
        setShowNameInput(true);
    }

    // Auto-start music logic on first click
    const startAudioOnFirstInteraction = () => {
      initAudio();
      window.removeEventListener('click', startAudioOnFirstInteraction);
    };
    window.addEventListener('click', startAudioOnFirstInteraction);

    return () => {
      window.removeEventListener('click', startAudioOnFirstInteraction);
    }
  }, []);

  // Save stats
  useEffect(() => {
    localStorage.setItem('misionMultiplicacionStats', JSON.stringify(stats));
  }, [stats]);

  // Timer Logic - Active in MISSION, CHALLENGE, and RECOVERY
  useEffect(() => {
    let timerId: any;
    
    // Only run timer if playing, time left, no feedback active, AND not in PRACTICE
    if (view === GameView.PLAYING && timeLeft > 0 && feedback === 'none' && gameMode !== GameMode.PRACTICE) {
      timerId = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            clearInterval(timerId);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else if (timeLeft === 0 && view === GameView.PLAYING && gameMode !== GameMode.PRACTICE) {
       handleTimeOut();
    }

    return () => {
      if (timerId) clearInterval(timerId);
    };
  }, [view, timeLeft, feedback, gameMode]);

  // Audio Toggle
  const handleToggleMute = () => {
    const muted = toggleMute();
    setIsMuted(muted);
    initAudio(); 
  };

  // Name Submission
  const handleNameSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (tempName.trim().length > 0) {
          playCorrectSound();
          setStats(prev => ({ ...prev, playerName: tempName.trim() }));
          setShowNameInput(false);
      } else {
          playWrongSound();
      }
  };

  // Particle Logic
  const triggerBurst = (x: number, y: number, color: string) => {
    const id = Date.now() + Math.random();
    setBursts(prev => [...prev, { id, x, y, color }]);
    setTimeout(() => {
      setBursts(prev => prev.filter(b => b.id !== id));
    }, 1000);
  };

  // Helper to add mistake to stats
  const trackMistake = (factorA: number, factorB: number) => {
      // Don't duplicate if already in list
      const exists = stats.missedQuestions.some(m => m.a === factorA && m.b === factorB);
      if (!exists) {
          setStats(prev => ({
              ...prev,
              missedQuestions: [...prev.missedQuestions, { a: factorA, b: factorB }]
          }));
      }
  };

  // Helper to remove mistake (Redemption)
  const redeemMistake = (factorA: number, factorB: number) => {
      setStats(prev => ({
          ...prev,
          missedQuestions: prev.missedQuestions.filter(m => !(m.a === factorA && m.b === factorB))
      }));
  };

  // Start Level Setup
  const prepareLevel = async (level: LevelConfig) => {
    initAudio();
    playClickSound();
    setSelectedLevel(level);
    setView(GameView.LOADING);
    setIsLaunching(false);
    
    if (gameMode === GameMode.MISSION) {
      setLoadingText(`Viajando a ${level.planetName}...`);
    } else if (gameMode === GameMode.PRACTICE) {
      setLoadingText(`Cargando entrenamiento: Tabla del ${level.tableNumber}...`);
    }
    
    const rawQ = await generateLevelQuestions(level.tableNumber, level.aiContext, level.missionDescription, level.missionItem);
    // Shuffle options here to ensure randomness in UI
    const q = rawQ.map(item => ({ ...item, options: shuffleOptions(item.options) }));

    setQuestions(q);
    setBriefingShown(false);
    
    if (gameMode === GameMode.PRACTICE) {
      startPlaying(q, 0); // Practice has no time limit
    } else {
      setLoadingText("¡Llegada Inminente!");
      setTimeout(() => setBriefingShown(true), 1500); 
    }
  };

  const startChallengeLevel = async (stageIndex: number) => {
    initAudio();
    playClickSound();
    
    const stage = CHALLENGE_STAGES[stageIndex];
    if (!stage) return;

    setCurrentChallengeStageIndex(stageIndex);
    setView(GameView.LOADING);
    setLoadingText(`Preparando Desafío: ${stage.name}...`);
    
    const rawQ = await generateChallengeQuestions(stage.allowedTables, stage.questionCount);
    const q = rawQ.map(item => ({ ...item, options: shuffleOptions(item.options) }));
    
    setTimeout(() => {
        startPlaying(q, stage.timeLimit);
    }, 1500);
  };

  const startRecoveryLevel = () => {
    initAudio();
    playClickSound();
    setGameMode(GameMode.RECOVERY);
    setView(GameView.LOADING);
    setLoadingText("Analizando fallos del sistema...");

    const rawQ = generateRecoveryQuestions(stats.missedQuestions);
    const q = rawQ.map(item => ({ ...item, options: shuffleOptions(item.options) }));

    setTimeout(() => {
        startPlaying(q, 120); // Generous time limit for recovery
    }, 1500);
  };

  const handleMissionStart = () => {
      setIsLaunching(true);
      playLiftoffSound();
      setTimeout(() => {
          startPlaying(questions, 60); // Missions always 60s
          setIsLaunching(false);
      }, 800);
  };

  const startPlaying = (qs: Question[], duration: number) => {
    setQuestions(qs);
    setCurrentQIndex(0);
    // Keep score if continuing challenge, otherwise reset
    if (gameMode !== GameMode.CHALLENGE || currentChallengeStageIndex === 0) {
      setScore(0);
    }
    setHealth(MAX_HEALTH);
    setShakeHealth(false);
    setCorrectCount(0);
    setTimeLeft(duration);
    setFeedback('none');
    setSelectedOption(null);
    setTransitionState('in');
    setView(GameView.PLAYING);
  };

  // Handle Answer
  const handleAnswer = (answer: number, e?: React.MouseEvent) => {
    if (feedback !== 'none') return;

    const currentQ = questions[currentQIndex];
    const isCorrect = answer === currentQ.correctAnswer;
    let isGameOver = false;

    setSelectedOption(answer);

    // Particle effect on click position
    if (e) {
      const rect = e.currentTarget.getBoundingClientRect();
      triggerBurst(rect.left + rect.width / 2, rect.top + rect.height / 2, isCorrect ? '#4ade80' : '#f87171');
    }

    if (isCorrect) {
      setFeedback('correct');
      setScore(s => s + 100);
      setCorrectCount(c => c + 1);
      playCorrectSound();

      // REDEMPTION LOGIC: If in Recovery Mode, remove the mistake from stats
      if (gameMode === GameMode.RECOVERY) {
          redeemMistake(currentQ.factorA, currentQ.factorB);
      }
      
      // Celebration burst at robot position using Ref
      if (robotRef.current) {
        const rect = robotRef.current.getBoundingClientRect();
        const robotX = rect.left + rect.width / 2;
        const robotY = rect.top + rect.height / 2;
        setTimeout(() => triggerBurst(robotX, robotY, '#FACC15'), 200);
      }

    } else {
      setFeedback('wrong');
      playWrongSound();
      
      // Track Mistake
      trackMistake(currentQ.factorA, currentQ.factorB);
      
      // Damage Logic (Mission & Challenge & Recovery)
      if (gameMode !== GameMode.PRACTICE) {
        const newHealth = health - 1;
        setHealth(newHealth);
        setShakeHealth(true);
        setTimeout(() => setShakeHealth(false), 500);
        if (newHealth <= 0) {
          isGameOver = true;
        }
      }
    }

    setTimeout(() => {
      if (isGameOver) {
        setView(GameView.GAME_OVER);
        playGameOverSound();
      } else {
        setFeedback('none');
        setSelectedOption(null);
        if (currentQIndex < questions.length - 1) {
          // Trigger slide out
          setTransitionState('out');
          // Wait for slide out to finish, then update question and slide in
          setTimeout(() => {
            setCurrentQIndex(i => i + 1);
            setTransitionState('in');
          }, 500);
        } else {
          endLevel(isCorrect ? score + 100 : score);
        }
      }
    }, 1500);
  };

  const handleTimeOut = () => {
    if (feedback === 'timeout') return;
    setFeedback('timeout');
    playTimeoutSound();
    
    // Track mistake on timeout too
    const currentQ = questions[currentQIndex];
    if (currentQ) trackMistake(currentQ.factorA, currentQ.factorB);
    
    const newHealth = health - 1;
    setHealth(newHealth);
    setShakeHealth(true);
    setTimeout(() => setShakeHealth(false), 500);
    
    setTimeout(() => {
       if (health - 1 <= 0) {
         setView(GameView.GAME_OVER);
         playGameOverSound();
       } else {
         setFeedback('none');
         setSelectedOption(null);
         if (currentQIndex < questions.length - 1) {
            // Trigger slide out
            setTransitionState('out');
            setTimeout(() => {
                setCurrentQIndex(i => i + 1);
                setTransitionState('in');
            }, 500);
         } else {
            endLevel(score);
         }
       }
    }, 2000);
  };

  // End Level Logic
  const endLevel = (finalScore: number) => {
    const isMission = gameMode === GameMode.MISSION;
    const isChallenge = gameMode === GameMode.CHALLENGE;
    const isRecovery = gameMode === GameMode.RECOVERY;
    const percentage = questions.length > 0 ? (correctCount / questions.length) : 0;
    const passed = percentage > 0.6 || isRecovery; // Recovery is flexible

    let newStats = { ...stats, totalXp: stats.totalXp + finalScore };

    if (isMission && selectedLevel) {
      let earnedStars = 0;
      if (percentage >= 0.4) earnedStars = 1;
      if (percentage > 0.7) earnedStars = 2;
      if (percentage >= 0.95) earnedStars = 3;

      newStats.stars = {
        ...newStats.stars,
        [selectedLevel.tableNumber]: Math.max(newStats.stars[selectedLevel.tableNumber] || 0, earnedStars)
      };
    } else if (isChallenge) {
        // Unlock Trophy if passed
        const stage = CHALLENGE_STAGES[currentChallengeStageIndex];
        if (percentage >= 0.8 && stage.trophyReward && !newStats.trophies.includes(stage.trophyReward)) {
            newStats.trophies = [...newStats.trophies, stage.trophyReward];
        }
    } 
    // For Recovery, we already updated missedQuestions in real-time on correct answers

    setStats(newStats);

    if (passed) {
      playVictorySound();
      setView(GameView.CELEBRATION);
      
      // Auto-fire celebration bursts randomly
      for(let i=0; i<8; i++) {
        setTimeout(() => {
            const x = Math.random() * window.innerWidth;
            const y = Math.random() * window.innerHeight * 0.5; // Top half
            triggerBurst(x, y, ['#FACC15', '#4ADE80', '#F87171', '#60A5FA'][Math.floor(Math.random()*4)]);
        }, i * 300);
      }

      setTimeout(() => {
         setView(GameView.VICTORY);
      }, 4000);
    } else {
      setView(GameView.VICTORY);
    }
  };

  // --- RENDERERS ---

  const renderMuteButton = () => (
    <button 
      onClick={handleToggleMute}
      className="absolute top-4 right-4 z-50 p-2 bg-slate-800/80 rounded-full text-white hover:bg-slate-700 hover:scale-110 transition-all"
      title={isMuted ? "Activar Sonido" : "Silenciar"}
    >
      {isMuted ? <VolumeX size={24} /> : <Volume2 size={24} />}
    </button>
  );

  const renderNameInput = () => (
    <div className="fixed inset-0 z-50 bg-slate-900/95 flex flex-col items-center justify-center p-4 animate-in fade-in duration-500">
        <RobotMascot mood="happy" action="celebrate" />
        <div className="bg-slate-800 p-8 rounded-3xl border-4 border-cyan-500 shadow-2xl max-w-lg w-full text-center mt-8">
            <h2 className="text-3xl text-cyan-300 font-bold mb-2">IDENTIFICACIÓN REQUERIDA</h2>
            <p className="text-white text-lg mb-6">¡Hola! Soy Robo-X. ¿Cuál es tu nombre de Capitán?</p>
            
            <form onSubmit={handleNameSubmit} className="flex flex-col gap-4">
                <input 
                    type="text" 
                    value={tempName}
                    onChange={(e) => setTempName(e.target.value)}
                    placeholder="Escribe tu nombre o alias..."
                    className="w-full p-4 rounded-xl bg-slate-700 text-white text-2xl font-bold text-center border-2 border-slate-500 focus:border-cyan-400 focus:outline-none placeholder:text-slate-500 uppercase"
                    maxLength={12}
                    autoFocus
                />
                <button 
                    type="submit"
                    disabled={tempName.trim().length === 0}
                    className="bg-green-500 hover:bg-green-600 disabled:bg-slate-600 disabled:cursor-not-allowed text-white px-6 py-3 rounded-xl font-bold text-xl shadow-[0_4px_0_rgb(21,128,61)] hover:translate-y-[2px] hover:shadow-[0_2px_0_rgb(21,128,61)] transition-all"
                >
                    ¡CONFIRMAR IDENTIDAD!
                </button>
            </form>
        </div>
    </div>
  );

  const renderBriefing = () => {
    if (!selectedLevel) return null;
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4 max-w-2xl mx-auto text-center animate-in fade-in zoom-in duration-500">
        <RobotMascot mood={isLaunching ? 'happy' : 'neutral'} action={isLaunching ? 'liftoff' : undefined} />
        
        <div className={`transition-opacity duration-300 ${isLaunching ? 'opacity-0' : 'opacity-100'}`}>
            <h2 className="text-4xl text-cyan-400 font-bold mb-2 mt-4">INFORME DE MISIÓN</h2>
            <h3 className="text-2xl text-yellow-400 font-bold mb-4">{selectedLevel.missionTitle}</h3>
            
            <div className="bg-slate-800/90 p-8 rounded-2xl border-2 border-cyan-500/50 shadow-2xl mb-8">
            <p className="text-xl text-white leading-relaxed mb-6 font-medium">
                {selectedLevel.missionDescription}
            </p>
            <div className="flex justify-center gap-4">
                <div className="flex flex-col items-center p-3 bg-slate-900 rounded-lg border border-slate-700">
                <span className="text-xs text-slate-400 uppercase tracking-wider">Tabla</span>
                <span className="text-2xl font-bold text-white">{selectedLevel.tableNumber === 99 ? 'TODAS' : selectedLevel.tableNumber}</span>
                </div>
                <div className="flex flex-col items-center p-3 bg-slate-900 rounded-lg border border-slate-700">
                <span className="text-xs text-slate-400 uppercase tracking-wider">Objetivo</span>
                <span className="text-sm font-bold text-white max-w-[100px] truncate">{selectedLevel.missionItem}</span>
                </div>
            </div>
            </div>
            <button 
            onClick={handleMissionStart}
            disabled={isLaunching}
            className="bg-green-500 hover:bg-green-600 hover:brightness-110 text-white px-10 py-4 rounded-xl font-bold text-2xl shadow-[0_4px_0_rgb(21,128,61)] hover:translate-y-[2px] hover:shadow-[0_2px_0_rgb(21,128,61)] transition-all animate-bounce"
            >
            ¡ACEPTAR MISIÓN!
            </button>
        </div>
      </div>
    );
  };

  const renderMenu = () => (
    <div className="flex flex-col items-center justify-center min-h-screen p-4">
      {/* Pilot Profile Header */}
      <div className="absolute top-4 left-4 z-50 flex items-center gap-3 bg-slate-800/80 p-2 pr-4 rounded-full border border-slate-600">
          <div className="bg-cyan-600 p-2 rounded-full">
            <User className="text-white" size={20} />
          </div>
          <div className="flex flex-col items-start">
             <span className="text-xs text-slate-400 uppercase">Piloto</span>
             <span className="text-white font-bold leading-none">{stats.playerName || 'Cadete'}</span>
          </div>
          <button 
            onClick={() => { setTempName(stats.playerName); setShowNameInput(true); }}
            className="ml-2 text-slate-400 hover:text-white"
          >
            <Edit3 size={16} />
          </button>
      </div>

      <div className="mb-6 text-center animate-bounce">
        <h1 className="text-5xl md:text-7xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400 drop-shadow-lg">
          Misión: Multiplicar
        </h1>
        <p className="text-blue-200 mt-2 text-xl">
           ¡Bienvenido a bordo, Capitán <span className="font-bold text-cyan-300">{stats.playerName}</span>!
        </p>
      </div>
      
      {/* Recovery Button (Only if mistakes exist) */}
      {stats.missedQuestions.length > 0 && (
         <button 
            onClick={() => { startRecoveryLevel() }}
            className="mb-6 flex items-center gap-3 bg-red-600 hover:bg-red-500 text-white px-8 py-3 rounded-xl font-bold text-xl shadow-[0_0_15px_rgba(220,38,38,0.6)] animate-pulse transition-all hover:scale-105"
         >
            <Stethoscope size={28} />
            Misión de Recuperación ({stats.missedQuestions.length} fallos)
         </button>
      )}

      {/* Mode Selector */}
      <div className="flex flex-wrap justify-center gap-2 p-1 bg-slate-800/80 rounded-xl mb-8 border border-slate-700">
        <button 
          onClick={() => { playClickSound(); setGameMode(GameMode.MISSION); }}
          className={`flex items-center gap-2 px-6 py-3 rounded-lg font-bold transition-all ${
            gameMode === GameMode.MISSION 
            ? 'bg-purple-600 text-white shadow-lg hover:brightness-110 hover:scale-105' 
            : 'text-slate-400 hover:text-white hover:bg-slate-700/50 hover:scale-105'
          }`}
        >
          <Rocket size={20} /> Misiones
        </button>
        <button 
          onClick={() => { playClickSound(); setGameMode(GameMode.CHALLENGE); }}
          className={`flex items-center gap-2 px-6 py-3 rounded-lg font-bold transition-all ${
            gameMode === GameMode.CHALLENGE 
            ? 'bg-orange-600 text-white shadow-lg hover:brightness-110 hover:scale-105' 
            : 'text-slate-400 hover:text-white hover:bg-slate-700/50 hover:scale-105'
          }`}
        >
          <Award size={20} /> Desafío
        </button>
        <button 
          onClick={() => { playClickSound(); setGameMode(GameMode.PRACTICE); }}
          className={`flex items-center gap-2 px-6 py-3 rounded-lg font-bold transition-all ${
            gameMode === GameMode.PRACTICE 
            ? 'bg-green-600 text-white shadow-lg hover:brightness-110 hover:scale-105' 
            : 'text-slate-400 hover:text-white hover:bg-slate-700/50 hover:scale-105'
          }`}
        >
          <BookOpen size={20} /> Práctica
        </button>
      </div>

      {/* Render based on mode */}
      {gameMode === GameMode.CHALLENGE ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl w-full">
            {CHALLENGE_STAGES.map((stage, idx) => {
                const isLocked = idx > 0 && !stats.trophies.includes(CHALLENGE_STAGES[idx-1].trophyReward || '');
                // Allow playing if previous earned trophy or it's the first one
                return (
                    <button
                        key={stage.id}
                        disabled={isLocked}
                        onClick={() => startChallengeLevel(idx)}
                        className={`group relative flex flex-col p-6 rounded-2xl border-2 text-left transition-all duration-300 transform hover:scale-105 ${
                            isLocked 
                            ? 'bg-slate-800/50 border-slate-700 opacity-60 cursor-not-allowed' 
                            : 'bg-slate-800/80 border-orange-500/50 hover:bg-slate-700/80 hover:border-orange-400 hover:shadow-[0_0_20px_rgba(249,115,22,0.4)]'
                        }`}
                    >
                        <div className="flex justify-between items-start mb-2">
                             <span className={`text-2xl font-bold ${isLocked ? 'text-slate-500' : 'text-orange-300'}`}>{stage.name}</span>
                             {stage.trophyReward && <TrophyIcon earned={stats.trophies.includes(stage.trophyReward)} />}
                        </div>
                        <p className="text-slate-400 text-sm mb-4">{stage.description}</p>
                        <div className="flex gap-4 text-xs font-mono text-slate-500">
                            <span className="flex items-center gap-1"><Timer size={14}/> {stage.timeLimit}s</span>
                            <span className="flex items-center gap-1"><BookOpen size={14}/> {stage.questionCount} Preguntas</span>
                        </div>
                    </button>
                )
            })}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 md:gap-8 max-w-5xl w-full">
            {PLANETS.map((planet) => {
            const stars = stats.stars[planet.tableNumber] || 0;
            const isSuper = planet.tableNumber === 99;
            return (
                <button
                key={planet.tableNumber}
                onClick={() => prepareLevel(planet)}
                className={`group relative flex flex-col items-center p-4 bg-slate-800/50 rounded-2xl border-2 hover:bg-slate-700/80 transition-all duration-300 transform hover:scale-110 ${isSuper ? 'border-purple-500 hover:border-pink-400 col-span-2 md:col-span-1 md:col-start-3 shadow-[0_0_20px_rgba(236,72,153,0.3)]' : 'border-slate-700 hover:border-cyan-400 hover:shadow-[0_0_20px_rgba(6,182,212,0.4)]'}`}
                >
                <PlanetIcon color={planet.planetColor} id={planet.tableNumber} />
                
                {gameMode === GameMode.MISSION && (
                    <div className="absolute top-2 right-2 flex gap-0.5">
                    {[1, 2, 3].map(i => <Star key={i} filled={i <= stars} />)}
                    </div>
                )}
                
                <span className={`mt-2 text-2xl font-bold ${isSuper ? 'text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-pink-500' : 'text-white'}`}>
                    {isSuper ? 'SUPER' : `Tabla del ${planet.tableNumber}`}
                </span>
                <span className="text-xs text-slate-400">{planet.planetName}</span>
                </button>
            )
            })}
        </div>
      )}
      
      {gameMode === GameMode.PRACTICE && (
        <div className="mt-8 text-green-300 bg-green-900/30 px-6 py-2 rounded-full border border-green-500/30">
          Modo Práctica: Sin tiempo, feedback inmediato. ¡Aprende a tu ritmo!
        </div>
      )}
    </div>
  );

  const renderLoading = () => {
    if (briefingShown && gameMode === GameMode.MISSION) return renderBriefing();

    return (
      <div className="flex flex-col items-center justify-center min-h-screen">
         <RobotMascot mood="thinking" />
         <h2 className="text-3xl text-white mt-8 animate-pulse text-center px-4">{loadingText}</h2>
         <div className="mt-4 w-64 h-4 bg-slate-700 rounded-full overflow-hidden">
           <div className="h-full bg-cyan-500 animate-[width_2s_ease-in-out_infinite]" style={{ width: '50%' }}></div>
         </div>
         {gameMode === GameMode.MISSION && (
           <p className="mt-4 text-slate-400 text-sm italic max-w-md text-center">
             La IA está analizando los parámetros de la misión...
           </p>
         )}
      </div>
    );
  };

  const renderCelebration = () => {
     return (
        <div className="flex flex-col items-center justify-center min-h-screen overflow-hidden relative">
            {/* Robot Flying Across */}
            <div className="absolute z-20 fly-across pointer-events-none">
                <RobotMascot mood="happy" action="celebrate" />
                <div className="absolute top-20 left-10 w-20 h-40 bg-gradient-to-t from-orange-500 to-transparent opacity-50 blur-xl transform rotate-180"></div>
            </div>

            {/* Giant Text */}
            <h1 className="text-6xl md:text-9xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-orange-400 to-red-500 stamp-in drop-shadow-[0_10px_10px_rgba(0,0,0,0.5)] z-30 text-center px-4">
                ¡MISIÓN<br/>CUMPLIDA!
            </h1>

            {/* Planet Conquered */}
            {selectedLevel && (
                <div className="mt-12 relative z-10 animate-[spin_30s_linear_infinite]">
                    <PlanetIcon color={selectedLevel.planetColor} size="w-48 h-48" id={selectedLevel.tableNumber} />
                    <div className="absolute -top-10 right-0 z-40 plant-flag origin-bottom-left">
                        <FlagIcon />
                    </div>
                </div>
            )}
            
            {/* Challenge Trophy Placeholder */}
            {gameMode === GameMode.CHALLENGE && (
                <div className="mt-12 relative z-10 animate-bounce">
                    <TrophyIcon earned={true} color="#FACC15" />
                </div>
            )}
        </div>
     );
  };

  const renderGame = () => {
    const q = questions[currentQIndex];
    if (!q) return renderLoading();

    const isTimeLow = timeLeft <= 10 && gameMode !== GameMode.PRACTICE;
    const isBoss = q.type === 'BOSS' || gameMode === GameMode.RECOVERY;

    let robotMood: 'happy' | 'sad' | 'thinking' | 'neutral' = 'neutral';
    let robotAction: 'liftoff' | 'celebrate' | 'shake' | undefined = undefined;

    if (feedback === 'correct') {
      robotMood = 'happy';
      robotAction = 'celebrate';
    } else if (feedback === 'wrong') {
      robotMood = 'sad';
      robotAction = 'shake';
    } else if (feedback === 'timeout') {
      robotMood = 'sad';
      robotAction = 'shake';
    } else if (isTimeLow) {
      robotMood = 'thinking';
    }

    const progressPercent = ((currentQIndex + 1) / questions.length) * 100;

    return (
      <div className={`flex flex-col items-center min-h-screen p-4 max-w-4xl mx-auto transition-colors duration-1000 ${isBoss ? 'bg-red-900/20' : ''}`}>
        {/* HUD */}
        <div className="w-full flex justify-between items-center mb-8 p-4 bg-slate-800/80 rounded-xl backdrop-blur-sm border border-slate-700">
           <button onClick={() => { playClickSound(); setView(GameView.MENU); }} className="p-2 hover:bg-white/10 rounded-full hover:scale-110 transition-transform">
             <Home className="text-white" />
           </button>
           
           {gameMode !== GameMode.PRACTICE ? (
             <div className="flex gap-4 items-center">
                <div className={`flex gap-1 bg-slate-900/50 px-3 py-1 rounded-full border border-slate-600/50 ${shakeHealth ? 'shake' : ''}`}>
                    {[...Array(MAX_HEALTH)].map((_, i) => (
                        <HealthHeart key={i} filled={i < health} />
                    ))}
                </div>
                
                <div className={`flex items-center gap-2 font-bold text-2xl ${isTimeLow ? 'text-red-500 animate-pulse' : 'text-cyan-300'}`}>
                  <Timer className={isTimeLow ? 'animate-bounce' : ''} />
                  <span>{timeLeft}s</span>
                </div>
             </div>
           ) : (
             <div className="flex items-center gap-2 font-bold text-xl text-green-400">
               <BookOpen size={24} />
               <span>PRÁCTICA</span>
             </div>
           )}

           <div className="flex gap-4">
              <div className="flex items-center gap-2">
                {gameMode === GameMode.MISSION ? (
                   <>
                    <span className="text-yellow-400 font-bold text-xl">Exp:</span>
                    <span className="text-white text-xl">{score}</span>
                   </>
                ) : gameMode === GameMode.CHALLENGE ? (
                    <>
                    <span className="text-orange-400 font-bold text-xl">Nivel</span>
                    <span className="text-white text-xl">{currentChallengeStageIndex + 1}</span>
                    </>
                ) : gameMode === GameMode.RECOVERY ? (
                   <>
                    <span className="text-red-400 font-bold text-xl"><Stethoscope size={24} /></span>
                    <span className="text-white text-xl">{questions.length - correctCount}</span>
                   </>
                ) : (
                   <>
                    <span className="text-green-400 font-bold text-xl">✓</span>
                    <span className="text-white text-xl">{correctCount}</span>
                   </>
                )}
              </div>
           </div>
        </div>

        {/* Question Area */}
        <div className="flex-1 w-full flex flex-col items-center justify-center relative">
          
          <div ref={robotRef} className="absolute -top-10 md:top-0 right-0 md:-right-10 pointer-events-none opacity-50 md:opacity-100 transition-all duration-300">
             <RobotMascot mood={robotMood} action={robotAction} />
          </div>

          <div className={`bg-slate-800/90 p-8 rounded-3xl border-4 ${isBoss ? 'border-red-500 shadow-red-900/50' : 'border-slate-600'} w-full text-center shadow-2xl relative overflow-hidden transition-all duration-500 ${transitionState === 'out' ? 'slide-out-left' : 'slide-in-right'}`}>
            
            {isBoss && (
              <div className="absolute top-0 left-0 w-full bg-red-600 text-white text-xs font-bold py-1 uppercase tracking-widest z-10">
                {gameMode === GameMode.RECOVERY ? 'PROTOCOLO DE RECUPERACIÓN' : 'Sistema de Seguridad Alienígena'}
              </div>
            )}

            {/* Progress Indicator */}
            <div className={`w-full flex flex-col items-center mb-6 z-10 relative ${isBoss ? 'mt-6' : ''}`}>
                 <div className="w-full max-w-md h-2 bg-slate-700/50 rounded-full overflow-hidden mb-2">
                    <div 
                        className={`h-full transition-all duration-500 ease-out ${isBoss ? 'bg-red-500' : 'bg-cyan-400'}`} 
                        style={{ width: `${progressPercent}%` }}
                    />
                 </div>
                 <div className="text-slate-400 text-xs font-bold uppercase tracking-widest">
                    Misión: {currentQIndex + 1} / {questions.length}
                 </div>
            </div>

            {feedback !== 'none' && (
              <div className={`absolute inset-0 z-20 flex items-center justify-center pointer-events-none`}>
                  <div className={`text-5xl md:text-6xl font-black transition-transform duration-300 drop-shadow-[0_4px_4px_rgba(0,0,0,0.8)] ${
                    feedback === 'correct' ? 'text-green-400 scale-125' : 
                    feedback === 'wrong' ? 'text-red-400 shake' : 
                    'text-orange-400' 
                  }`}>
                    {feedback === 'correct' ? '¡GENIAL!' : 
                     feedback === 'wrong' ? '¡OH NO!' : 
                     '¡TIEMPO!'}
                  </div>
              </div>
            )}

            <h2 className="text-2xl md:text-3xl text-cyan-200 mb-6 font-bold mt-2 leading-relaxed">{q.storyContext}</h2>
            
            <div className={`text-6xl md:text-8xl font-black text-white mb-10 tracking-widest bg-slate-900/50 p-6 rounded-2xl inline-block border-2 ${isBoss ? 'border-red-500/50 text-red-100' : 'border-slate-700'}`}>
              {q.factorA} × {q.factorB} = ?
            </div>

            {/* Answer Grid - Updated for 5 options with Wrap */}
            <div className="flex flex-wrap justify-center gap-4 mt-4 relative z-30">
              {q.options.map((opt, idx) => {
                let btnClass = "bg-indigo-600 hover:bg-indigo-500 shadow-[0_4px_0_rgb(55,48,163)] hover:shadow-[0_2px_0_rgb(55,48,163)] hover:scale-105 hover:brightness-110";
                
                if (isBoss) {
                  btnClass = "bg-red-700 hover:bg-red-600 shadow-[0_4px_0_rgb(153,27,27)] hover:shadow-[0_2px_0_rgb(153,27,27)] hover:scale-105 hover:brightness-110";
                }

                if (feedback === 'correct') {
                  if (opt === q.correctAnswer) {
                     btnClass = "bg-green-500 shadow-[0_0_20px_rgba(34,197,94,0.6)] ring-4 ring-green-300 scale-105 z-40";
                  } else {
                     btnClass = "bg-slate-700 opacity-30 scale-95";
                  }
                } else if (feedback === 'wrong') {
                   if (opt === selectedOption) {
                      btnClass = "bg-red-500 ring-4 ring-red-400 shake-flash z-40";
                   } else {
                      btnClass = "bg-slate-700 opacity-50";
                   }
                }

                return (
                  <button
                    key={idx}
                    onClick={(e) => handleAnswer(opt, e)}
                    disabled={feedback !== 'none'}
                    className={`py-4 px-6 md:py-6 md:px-8 text-white text-3xl md:text-4xl font-bold rounded-2xl transition-all duration-300 transform min-w-[120px] md:min-w-[140px] flex-grow md:flex-grow-0 ${btnClass} disabled:pointer-events-none`}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderVictory = () => {
    const isMission = gameMode === GameMode.MISSION;
    const isChallenge = gameMode === GameMode.CHALLENGE;
    const isRecovery = gameMode === GameMode.RECOVERY;
    const accuracy = Math.round((correctCount / questions.length) * 100);
    const passed = accuracy > 60; // 60% pass rate general
    
    // Determine title
    let title = "¡Entrenamiento Completado!";
    if (isMission) title = passed ? "¡Misión Cumplida!" : "¡Buen Intento!";
    if (isChallenge) title = passed ? "¡Desafío Superado!" : "¡Casi lo logras!";
    if (isRecovery) title = passed ? "¡Sistemas Recuperados!" : "Recuperación Incompleta";

    const currentChallenge = CHALLENGE_STAGES[currentChallengeStageIndex];
    const hasNextChallenge = currentChallengeStageIndex < CHALLENGE_STAGES.length - 1;

    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4 text-center">
        <RobotMascot mood={passed ? "happy" : "neutral"} />
        
        <h1 className={`text-5xl md:text-7xl font-bold mb-4 mt-4 drop-shadow-lg ${passed ? 'text-yellow-400' : 'text-slate-300'}`}>
          {title}
        </h1>

        {isMission && passed && (
          <div className="flex gap-4 mb-8">
            {[1, 2, 3].map(i => {
               const stars = stats.stars[selectedLevel?.tableNumber || 0] || 0;
               return (
               <div key={i} className={`transform transition-all duration-500 delay-${i * 100} ${i <= stars ? 'scale-125' : 'scale-100 opacity-30'}`}>
                  <StarIcon className={`w-20 h-20 ${i <= stars ? 'text-yellow-400 fill-yellow-400' : 'text-gray-400'}`} />
               </div>
            )})}
          </div>
        )}

        {isChallenge && passed && currentChallenge.trophyReward && (
            <div className="flex flex-col items-center mb-8 animate-bounce">
                <TrophyIcon earned={true} />
                <span className="text-orange-300 mt-2 font-bold">¡Trofeo Desbloqueado!</span>
            </div>
        )}

        <div className="text-2xl text-white mb-8">
            <span className="text-slate-300 text-lg block">Precisión: {accuracy}%</span>
            {isMission && <span className="text-cyan-400 font-bold block mt-2">Puntos: {score}</span>}
            {isRecovery && <span className="text-red-400 font-bold block mt-2">Fallos restantes: {stats.missedQuestions.length}</span>}
        </div>
        
        <div className="flex gap-4">
          <button 
            onClick={() => { playClickSound(); setView(GameView.MENU); }}
            className="flex items-center gap-2 bg-slate-700 hover:bg-slate-600 hover:scale-105 hover:brightness-110 text-white px-8 py-4 rounded-xl font-bold text-xl transition-all"
          >
            <Home /> Menú
          </button>
          
          {isChallenge && passed && hasNextChallenge ? (
            <button 
                onClick={() => startChallengeLevel(currentChallengeStageIndex + 1)}
                className="flex items-center gap-2 bg-orange-500 hover:bg-orange-600 hover:scale-105 hover:brightness-110 text-white px-8 py-4 rounded-xl font-bold text-xl shadow-[0_4px_0_rgb(194,65,12)] hover:translate-y-[2px] hover:shadow-[0_2px_0_rgb(194,65,12)] transition-all"
            >
                Siguiente Nivel <ArrowRight />
            </button>
          ) : (
            <button 
                onClick={() => { 
                    playClickSound(); 
                    if (isRecovery) {
                        if (stats.missedQuestions.length > 0) startRecoveryLevel();
                        else setView(GameView.MENU);
                    }
                    else if (selectedLevel) prepareLevel(selectedLevel); 
                }}
                className="flex items-center gap-2 bg-green-500 hover:bg-green-600 hover:scale-105 hover:brightness-110 text-white px-8 py-4 rounded-xl font-bold text-xl shadow-[0_4px_0_rgb(21,128,61)] hover:translate-y-[2px] hover:shadow-[0_2px_0_rgb(21,128,61)] transition-all"
            >
                <RotateCcw /> {isRecovery ? (stats.missedQuestions.length > 0 ? "Seguir Reparando" : "Volver") : "Repetir"}
            </button>
          )}
        </div>
      </div>
    );
  };

  const renderGameOver = () => (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 text-center bg-red-900/30">
      <RobotMascot mood="sad" />
      <h1 className="text-5xl md:text-7xl font-bold text-red-500 mb-4 mt-6 drop-shadow-lg animate-pulse">
        ¡MISIÓN FALLIDA!
      </h1>
      <p className="text-2xl text-slate-300 mb-8 max-w-md">
        El robot se ha quedado sin energía. ¡No te rindas, inténtalo de nuevo!
      </p>

      <div className="flex gap-4">
          <button 
            onClick={() => { playClickSound(); setView(GameView.MENU); }}
            className="flex items-center gap-2 bg-slate-700 hover:bg-slate-600 hover:scale-105 hover:brightness-110 text-white px-8 py-4 rounded-xl font-bold text-xl transition-all"
          >
            <Home /> Salir
          </button>
          <button 
            onClick={() => { 
                playClickSound(); 
                if (gameMode === GameMode.CHALLENGE) startChallengeLevel(currentChallengeStageIndex);
                else if (gameMode === GameMode.RECOVERY) startRecoveryLevel();
                else if (selectedLevel) prepareLevel(selectedLevel); 
            }}
            className="flex items-center gap-2 bg-cyan-600 hover:bg-cyan-500 hover:scale-105 hover:brightness-110 text-white px-8 py-4 rounded-xl font-bold text-xl shadow-[0_4px_0_rgb(8,145,178)] hover:translate-y-[2px] hover:shadow-[0_2px_0_rgb(8,145,178)] transition-all"
          >
            <RotateCcw /> Reintentar
          </button>
      </div>
    </div>
  );

  return (
    <div className="relative min-h-screen w-full font-fredoka overflow-hidden select-none">
      <SpaceBackground />
      {/* Particle Container */}
      {bursts.map(b => (
        <ParticleBurst key={b.id} x={b.x} y={b.y} color={b.color} />
      ))}
      
      {/* Name Input Overlay */}
      {showNameInput && renderNameInput()}

      {renderMuteButton()}
      <div className="relative z-10">
        {view === GameView.MENU && renderMenu()}
        {view === GameView.LOADING && renderLoading()}
        {view === GameView.PLAYING && renderGame()}
        {view === GameView.CELEBRATION && renderCelebration()}
        {view === GameView.VICTORY && renderVictory()}
        {view === GameView.GAME_OVER && renderGameOver()}
      </div>
    </div>
  );
}