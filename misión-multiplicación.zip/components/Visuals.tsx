import React from 'react';

export const PlanetIcon: React.FC<{ color: string; size?: string; id?: number }> = ({ color, size = "w-16 h-16", id = 0 }) => {
  
  // Assign unique animation classes based on the planet ID
  let animClass = '';
  let ringClass = '';
  
  // Special case for Super Level (99)
  if (id === 99) {
      animClass = 'spin-slow'; 
  } else {
    switch(id % 10) {
        case 0: animClass = 'scale-pulse'; break; // Black hole / Void
        case 1: animClass = 'spin-slow'; break; // Rotation
        case 2: animClass = 'wobble-slow'; break; // Unstable
        case 3: animClass = 'glow-pulse'; break; // Sun/Star
        case 4: animClass = 'bounce-gentle'; break; // Rover terrain
        case 5: animClass = 'spin-reverse'; break; // Counter rotation
        case 6: animClass = 'float-anim'; break; // Beehive
        case 7: animClass = 'bounce-gentle'; break; // Heavy
        case 8: animClass = 'wobble-slow'; ringClass = 'ring-spin'; break; // Ringed
        case 9: animClass = 'scale-pulse'; break; // Nebula
        default: animClass = 'float-anim';
    }
  }

  return (
    <svg className={`${size} drop-shadow-lg ${animClass}`} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ color: color }}>
      {id === 99 ? (
          /* Supernova / Rainbow Planet */
          <>
            <defs>
                <radialGradient id="supernovaGrad" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
                    <stop offset="0%" stopColor="#fbbf24" />
                    <stop offset="40%" stopColor="#f87171" />
                    <stop offset="80%" stopColor="#8b5cf6" />
                    <stop offset="100%" stopColor="#1e293b" />
                </radialGradient>
            </defs>
            <circle cx="50" cy="50" r="45" fill="url(#supernovaGrad)" />
            <path d="M50 5 Q 95 50 50 95 Q 5 50 50 5" stroke="white" strokeWidth="2" opacity="0.4" className="spin-reverse" />
            <path d="M50 15 Q 85 50 50 85 Q 15 50 50 15" stroke="white" strokeWidth="2" opacity="0.6" className="spin-slow" />
            <circle cx="50" cy="50" r="48" stroke="white" strokeWidth="2" strokeDasharray="4 8" className="spin-slow" opacity="0.5" />
          </>
      ) : (
          /* Standard Planet Body */
          <circle cx="50" cy="50" r="45" fill={color} opacity="0.8" />
      )}
      
      {/* Ring / Atmosphere - Animated independently for planet 8 */}
      {id === 8 && (
        <circle 
            cx="50" cy="50" r="40" 
            stroke="white" strokeWidth="4" 
            strokeDasharray="5 10" 
            opacity="0.5" 
            className={ringClass}
        />
      )}
      
      {/* Global Surface Detail (Except Supernova) */}
      {id !== 99 && <path d="M10 50 Q 50 20 90 50" stroke="white" strokeWidth="3" opacity="0.3" fill="none" />}

      {/* Unique Surface Features based on ID */}
      {id === 0 && ( /* Vortex/Black Hole */
         <path d="M50 50 m-25 0 a 25 25 0 1 0 50 0 a 25 25 0 1 0 -50 0" stroke="white" strokeWidth="2" strokeDasharray="3 5" opacity="0.4" className="spin-slow" />
      )}
      {id === 1 && ( /* One large crater */
         <circle cx="65" cy="35" r="12" fill="white" opacity="0.2" />
      )}
      {id === 2 && ( /* Dual stripes for Duo-Terra */
         <path d="M25 35 L75 35 M25 65 L75 65" stroke="white" strokeWidth="3" opacity="0.3" strokeLinecap="round" />
      )}
      {id === 3 && ( /* Sun core */
         <circle cx="50" cy="50" r="25" fill="white" opacity="0.3" className="animate-pulse" />
      )}
      {id === 4 && ( /* Square/Tech pattern */
         <rect x="35" y="35" width="30" height="30" stroke="white" strokeWidth="2" opacity="0.3" rx="4" />
      )}
      {id === 5 && ( /* Star/Alien shape */
         <path d="M50 25 L60 45 L80 45 L65 60 L70 80 L50 70 L30 80 L35 60 L20 45 L40 45 Z" fill="white" opacity="0.2" />
      )}
      {id === 6 && ( /* Hexagon for Hive */
        <path d="M30 50 L40 30 L60 30 L70 50 L60 70 L40 70 Z" stroke="white" strokeWidth="3" opacity="0.3" fill="none" />
      )}
      {id === 7 && ( /* Heavy/Dense Block */
        <rect x="40" y="40" width="20" height="20" fill="white" opacity="0.4" transform="rotate(45 50 50)" />
      )}
      {/* 8 is handled by the ring above */}
      {id === 9 && ( /* Nebula Clouds */
        <path d="M20 50 Q 40 30 60 50 T 100 50" stroke="white" strokeWidth="4" opacity="0.3" strokeLinecap="round" />
      )}

      {/* Common craters (except supernova) */}
      {id !== 99 && (
          <>
            <circle cx="30" cy="40" r="5" fill="white" opacity="0.4" />
            <circle cx="70" cy="60" r="8" fill="white" opacity="0.4" />
          </>
      )}
    </svg>
  );
};

interface RobotProps {
  mood?: 'happy' | 'neutral' | 'thinking' | 'sad';
  action?: 'liftoff' | 'celebrate' | 'shake';
}

export const RobotMascot: React.FC<RobotProps> = ({ mood = 'neutral', action }) => {
  const eyeColor = mood === 'thinking' ? '#FACC15' : mood === 'sad' ? '#94A3B8' : '#38BDF8';
  
  let mouthPath = "M35 70 Q 50 70 65 70"; // Neutral
  if (mood === 'happy') mouthPath = "M35 65 Q 50 75 65 65";
  if (mood === 'sad') mouthPath = "M35 75 Q 50 65 65 75";
  
  // Use specific animation class based on action, default to 'float-anim'
  let animClass = 'float-anim';
  if (action === 'liftoff') animClass = 'liftoff-anim';
  else if (action === 'celebrate') animClass = 'jump-anim';
  else if (action === 'shake') animClass = 'shake';
  
  return (
    <svg className={`w-32 h-32 ${animClass}`} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Antennas */}
      <path d="M50 20 L 50 10" stroke="#94A3B8" strokeWidth="4" />
      <circle cx="50" cy="10" r="4" fill="#F43F5E" className={mood === 'thinking' ? 'animate-pulse' : ''} />
      
      {/* Head */}
      <rect x="20" y="20" width="60" height="50" rx="10" fill="#E2E8F0" stroke="#475569" strokeWidth="3" />
      
      {/* Screen/Face */}
      <rect x="28" y="30" width="44" height="30" rx="5" fill="#1E293B" />
      
      {/* Eyes */}
      {mood === 'sad' ? (
         <>
           <line x1="36" y1="40" x2="44" y2="44" stroke={eyeColor} strokeWidth="3" strokeLinecap="round" />
           <line x1="56" y1="44" x2="64" y2="40" stroke={eyeColor} strokeWidth="3" strokeLinecap="round" />
         </>
      ) : (
        <>
          <circle cx="40" cy="42" r="4" fill={eyeColor} className="animate-pulse" />
          <circle cx="60" cy="42" r="4" fill={eyeColor} className="animate-pulse" />
        </>
      )}
      
      {/* Mouth */}
      <path d={mouthPath} stroke={eyeColor} strokeWidth="3" strokeLinecap="round" />
      
      {/* Body Hint */}
      <path d="M30 70 L 20 90" stroke="#94A3B8" strokeWidth="4" />
      <path d="M70 70 L 80 90" stroke="#94A3B8" strokeWidth="4" />
      
      {/* Thruster Fire (Only visible during liftoff) */}
      {action === 'liftoff' && (
        <path d="M35 90 Q 50 120 65 90" fill="#F59E0B" className="animate-pulse" />
      )}
    </svg>
  );
};

export const Star: React.FC<{ filled: boolean }> = ({ filled }) => (
  <svg className={`w-8 h-8 ${filled ? 'text-yellow-400' : 'text-slate-600'}`} fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
  </svg>
);

export const HealthHeart: React.FC<{ filled: boolean }> = ({ filled }) => (
  <svg 
    className={`w-8 h-8 drop-shadow-md ${
      filled 
        ? 'text-red-500 fill-red-500 scale-100 transition-all duration-300' 
        : 'heart-break' 
    }`} 
    viewBox="0 0 24 24" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    fill="none"
  >
    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
  </svg>
);

export const TrophyIcon: React.FC<{ earned: boolean, color?: string }> = ({ earned, color = "#FACC15" }) => (
    <svg className={`w-12 h-12 transition-all duration-500 ${earned ? 'opacity-100 drop-shadow-[0_0_10px_rgba(250,204,21,0.5)]' : 'opacity-20 grayscale'}`} viewBox="0 0 24 24" fill="none" stroke={earned ? color : "#64748b"} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6" />
        <path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18" />
        <path d="M4 22h16" />
        <path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22" />
        <path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22" />
        <path d="M18 2H6v7a6 6 0 0 0 12 0V2Z" fill={earned ? color : "none"} fillOpacity="0.2" />
    </svg>
);

export const FlagIcon: React.FC = () => (
    <svg className="w-16 h-16 drop-shadow-xl plant-flag" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z" fill="#10B981" stroke="#065F46" />
        <line x1="4" y1="22" x2="4" y2="15" stroke="#94A3B8" strokeWidth="3" />
    </svg>
);

export const SpaceBackground: React.FC = () => {
  // Generate random stars for background
  const stars = React.useMemo(() => Array.from({ length: 20 }).map((_, i) => ({
    top: `${Math.random() * 100}%`,
    left: `${Math.random() * 100}%`,
    size: Math.random() > 0.5 ? 'w-1 h-1' : 'w-2 h-2',
    delay: `${Math.random() * 3}s`
  })), []);

  return (
    <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-slate-900 via-purple-900 to-slate-900 opacity-90" />
      {stars.map((s, i) => (
        <div 
          key={i}
          className={`absolute bg-white rounded-full ${s.size} star-twinkle`}
          style={{ top: s.top, left: s.left, animationDelay: s.delay }}
        />
      ))}
    </div>
  );
};

export const ParticleBurst: React.FC<{ x: number; y: number; color?: string }> = ({ x, y, color = "#FACC15" }) => {
  // Generate particles with random angles and distances
  const particles = React.useMemo(() => Array.from({ length: 12 }).map((_, i) => ({
    angle: (i / 12) * 360 + Math.random() * 30,
    dist: 50 + Math.random() * 50,
    size: Math.random() * 6 + 4,
    delay: Math.random() * 0.1
  })), []);

  return (
    <div className="fixed pointer-events-none z-50" style={{ left: x, top: y }}>
      {particles.map((p, i) => (
        <div
          key={i}
          className="absolute rounded-full particle-anim"
          style={{
            width: p.size,
            height: p.size,
            backgroundColor: color,
            '--tx': `${Math.cos(p.angle * Math.PI / 180) * p.dist}px`,
            '--ty': `${Math.sin(p.angle * Math.PI / 180) * p.dist}px`,
            animationDelay: `${p.delay}s`
          } as React.CSSProperties}
        />
      ))}
    </div>
  );
};