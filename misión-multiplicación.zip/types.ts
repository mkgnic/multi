
export enum GameView {
  MENU = 'MENU',
  LOADING = 'LOADING',
  PLAYING = 'PLAYING',
  CELEBRATION = 'CELEBRATION',
  VICTORY = 'VICTORY',
  GAME_OVER = 'GAME_OVER'
}

export enum GameMode {
  MISSION = 'MISSION',
  PRACTICE = 'PRACTICE',
  CHALLENGE = 'CHALLENGE',
  RECOVERY = 'RECOVERY'
}

export interface Question {
  id: string;
  factorA: number;
  factorB: number;
  storyContext: string; // "El robot necesita 2 baterías..."
  options: number[];
  correctAnswer: number;
  type?: 'TRAVEL' | 'BOSS';
}

export interface MissedQuestion {
  a: number;
  b: number;
}

export interface PlayerStats {
  playerName: string; // New field for personalization
  stars: Record<number, number>; // Table number -> Stars earned (0-3)
  trophies: string[]; // Array of Trophy IDs earned in Challenge Mode
  missedQuestions: MissedQuestion[]; // List of errors to recover
  totalXp: number;
}

export interface LevelConfig {
  tableNumber: number;
  planetName: string;
  planetColor: string;
  missionTitle: string;
  missionDescription: string;
  aiContext: string; // Specific context prompt for the AI
  missionItem: string; // The specific item to count/calculate (e.g., "ruedas", "kilos")
}

export interface ChallengeStage {
  id: string;
  name: string;
  allowedTables: number[]; // e.g., [0, 1, 2]
  questionCount: number;
  timeLimit: number; // Seconds
  trophyReward?: string; // ID of trophy if completed
  description: string;
}