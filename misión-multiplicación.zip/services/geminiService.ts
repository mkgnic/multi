
import { GoogleGenAI, Type, Schema } from "@google/genai";
import { Question, MissedQuestion } from "../types";

// Fisher-Yates Shuffle for true randomness
function shuffleArray<T>(array: T[]): T[] {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
}

// Safety fallback questions if API fails or key is missing
const FALLBACK_QUESTIONS: Record<number, Question[]> = {
  2: [
    { id: 'f1', factorA: 2, factorB: 3, storyContext: "¡Alerta! Hay 2 naves con 3 aliens cada una.", options: [5, 6, 8, 4, 9], correctAnswer: 6, type: 'TRAVEL' },
    { id: 'f2', factorA: 2, factorB: 5, storyContext: "Necesitamos 2 pares de botas espaciales. ¿Cuántas botas son?", options: [10, 4, 8, 12, 7], correctAnswer: 10, type: 'TRAVEL' },
    { id: 'f3', factorA: 2, factorB: 8, storyContext: "El robot tiene 2 brazos con 8 botones cada uno.", options: [16, 14, 10, 18, 12], correctAnswer: 16, type: 'TRAVEL' },
    { id: 'b1', factorA: 2, factorB: 2, storyContext: "CÓDIGO SECRETO: 2 x 2", options: [4, 6, 2, 8, 0], correctAnswer: 4, type: 'BOSS' },
    { id: 'b2', factorA: 2, factorB: 9, storyContext: "CÓDIGO SECRETO: 2 x 9", options: [18, 11, 20, 16, 19], correctAnswer: 18, type: 'BOSS' },
    { id: 'b3', factorA: 2, factorB: 6, storyContext: "CÓDIGO SECRETO: 2 x 6", options: [12, 8, 14, 10, 16], correctAnswer: 12, type: 'BOSS' },
  ]
};

// Helper to generate N unique options including the correct answer
const generateOptions = (correct: number, count: number = 5): number[] => {
    const options = new Set<number>();
    options.add(correct);
    
    while(options.size < count) {
        const offset = Math.floor(Math.random() * 10) + 1;
        const sign = Math.random() > 0.5 ? 1 : -1;
        // Generate a plausible fake answer (close to real one)
        let fake = correct + (offset * sign);
        
        // Sometimes use a "table error" (e.g. answer +/- factorA)
        if (Math.random() > 0.7) {
            fake = Math.random() > 0.5 ? correct + 2 : correct - 2; // Close miss
        }
        
        if (fake < 0) fake = Math.abs(fake); // No negatives
        if (fake !== correct) options.add(fake);
    }
    
    return shuffleArray(Array.from(options));
};

const getFallbackQuestions = (table: number): Question[] => {
  // Logic for Super Level Mixed Questions (Table 99)
  if (table === 99) {
      const qs: Question[] = [];
      for(let i=0; i<8; i++) { // Generate 8 mixed questions
          const a = Math.floor(Math.random() * 10);
          const b = Math.floor(Math.random() * 11);
          const ans = a * b;
          qs.push({
             id: `gen-mixed-${i}`,
             factorA: a,
             factorB: b,
             storyContext: `Desafío Galáctico: ${a} sistemas con ${b} estrellas.`,
             options: generateOptions(ans, 5),
             correctAnswer: ans,
             type: 'TRAVEL'
          });
      }
      return qs;
  }

  if (FALLBACK_QUESTIONS[table]) {
      // Shuffle the pre-defined fallback options just in case
      return FALLBACK_QUESTIONS[table].map(q => ({
          ...q,
          options: shuffleArray(q.options)
      }));
  }
  
  // Generic fallback generator
  const travelQs = [1, 2, 3, 4, 5].map(i => {
    const b = Math.floor(Math.random() * 9) + 1;
    const ans = table * b;
    return {
      id: `gen-travel-${i}`,
      factorA: table,
      factorB: b,
      storyContext: `Misión de respaldo: Calcula ${table} grupos de ${b} objetos.`,
      options: generateOptions(ans, 5),
      correctAnswer: ans,
      type: 'TRAVEL' as const
    };
  });

  const bossQs = [1, 2, 3].map(i => {
    const b = Math.floor(Math.random() * 9) + 1;
    const ans = table * b;
    return {
      id: `gen-boss-${i}`,
      factorA: table,
      factorB: b,
      storyContext: `DESACTIVAR CERROJO ${i}/3`,
      options: generateOptions(ans, 5),
      correctAnswer: ans,
      type: 'BOSS' as const
    };
  });

  return [...travelQs, ...bossQs];
};

export const generateLevelQuestions = async (tableNumber: number, aiContext?: string, missionDescription?: string, missionItem?: string): Promise<Question[]> => {
  if (!process.env.API_KEY) {
    console.warn("No API Key found, using fallback questions.");
    return getFallbackQuestions(tableNumber);
  }

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    // Schema for travel questions
    const travelSchema: Schema = {
      type: Type.OBJECT,
      properties: {
        questions: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              factorA: { type: Type.INTEGER },
              factorB: { type: Type.INTEGER },
              storyContext: { type: Type.STRING },
              options: { 
                type: Type.ARRAY,
                items: { type: Type.INTEGER }
              },
              correctAnswer: { type: Type.INTEGER }
            },
            required: ["factorA", "factorB", "storyContext", "options", "correctAnswer"]
          }
        }
      }
    };

    const isSuperLevel = tableNumber === 99;

    const contextStr = aiContext || "espacio, robots y planetas";
    const missionStr = missionDescription || "reparar la nave";
    const itemStr = missionItem || "objetos espaciales";

    const prompt = isSuperLevel 
    ? `
      Genera 8 preguntas de matemáticas de TODAS las tablas de multiplicar (0-9) mezcladas.
      
      MISIÓN: ${missionStr}
      
      Instrucciones:
      1. Genera problemas narrativos cortos donde se tenga que multiplicar dos números aleatorios (entre 0 y 9).
      2. 'factorA' y 'factorB' deben variar en cada pregunta.
      3. El 'storyContext' debe ser épico y variado.
      4. 'options': array con la respuesta correcta y 4 respuestas incorrectas (total 5).
    `
    : `
      Genera 5 preguntas de matemáticas (multiplicación) para un juego educativo (niños 5-9 años).
      
      TABLA: ${tableNumber} (factorA siempre es ${tableNumber})
      MISIÓN: ${missionStr}
      OBJETO CLAVE: ${itemStr}
      
      Instrucciones:
      1. Genera 5 problemas narrativos cortos donde se tenga que multiplicar ${tableNumber} por un número aleatorio (0-10).
      2. El 'storyContext' debe integrar la MISIÓN y el OBJETO CLAVE de forma natural.
      3. Mantén el lenguaje sencillo y divertido. Max 20 palabras por contexto.
      4. 'factorA' = ${tableNumber}. 'factorB' = número aleatorio.
      5. 'options': array con la respuesta correcta y 4 respuestas incorrectas creíbles (total 5 opciones).
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: travelSchema,
        temperature: 0.9 // Higher temp for more variety in Super Level
      }
    });

    const rawData = response.text;
    if (!rawData) throw new Error("No data returned");

    const parsedData = JSON.parse(rawData);
    
    const travelQuestions = parsedData.questions.map((q: any, index: number) => ({
      ...q,
      id: `ai-travel-${Date.now()}-${index}`,
      options: shuffleArray(q.options), // Shuffle AI options to be sure
      type: 'TRAVEL'
    }));

    // Generate Boss Questions
    // For Super Level, Boss questions are also mixed
    const bossQuestions = [1, 2, 3].map((i) => {
        const a = isSuperLevel ? Math.floor(Math.random() * 10) : tableNumber;
        const b = Math.floor(Math.random() * 11); // 0-10
        const ans = a * b;
        return {
            id: `ai-boss-${i}`,
            factorA: a,
            factorB: b,
            storyContext: isSuperLevel ? `PRUEBA FINAL ${i}/3` : `CERROJO DE SEGURIDAD ${i}/3`,
            options: generateOptions(ans, 5),
            correctAnswer: ans,
            type: 'BOSS'
        } as Question;
    });

    return [...travelQuestions, ...bossQuestions];

  } catch (error) {
    console.error("Gemini API Error:", error);
    return getFallbackQuestions(tableNumber);
  }
};

// Generate mixed questions for Challenge Mode
export const generateChallengeQuestions = async (allowedTables: number[], questionCount: number): Promise<Question[]> => {
    const questions: Question[] = [];
    
    for (let i = 0; i < questionCount; i++) {
        const factorA = allowedTables[Math.floor(Math.random() * allowedTables.length)];
        const factorB = Math.floor(Math.random() * 11); // 0-10
        const ans = factorA * factorB;
        
        questions.push({
            id: `challenge-${i}`,
            factorA,
            factorB,
            storyContext: `¡Calcula rápido!`,
            options: generateOptions(ans, 5),
            correctAnswer: ans,
            type: 'TRAVEL'
        });
    }

    return questions;
};

// Generate specific questions based on past mistakes
export const generateRecoveryQuestions = (mistakes: MissedQuestion[]): Question[] => {
    return mistakes.map((m, index) => {
        const ans = m.a * m.b;
        return {
            id: `recovery-${index}`,
            factorA: m.a,
            factorB: m.b,
            storyContext: "REPARACIÓN DE SISTEMA: Corrige el fallo.",
            options: generateOptions(ans, 5),
            correctAnswer: ans,
            type: 'BOSS' // Uses Boss styling (Red/Alert)
        };
    });
};
