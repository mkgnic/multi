
// Web Audio API Retro Synthesizer & Sequencer
// Theme: 90s Arcade / 8-bit Adventure

let audioCtx: AudioContext | null = null;
let masterGainNode: GainNode | null = null;
let isMuted = false;
let isMusicPlaying = false;

// -- Note Frequencies --
const N = {
  _: 0, // Rest
  C2: 65.41, D2: 73.42, E2: 82.41, F2: 87.31, G2: 98.00, A2: 110.00, B2: 123.47,
  C3: 130.81, D3: 146.83, E3: 164.81, F3: 174.61, Fs3: 185.00, G3: 196.00, A3: 220.00, B3: 246.94,
  C4: 261.63, D4: 293.66, E4: 329.63, F4: 349.23, G4: 392.00, A4: 440.00, B4: 493.88,
  C5: 523.25, D5: 587.33, E5: 659.25, F5: 698.46, G5: 783.99, A5: 880.00, B5: 987.77,
  C6: 1046.50, D6: 1174.66, E6: 1318.51, F6: 1396.91, G6: 1567.98
};

// -- Sequencer State --
let nextNoteTime = 0.0;
let currentStep = 0; // 0 to 63 (4 bars of 16th notes)
const SEQUENCE_LENGTH = 64;
const tempo = 125.0; // Slightly faster for more energy
const lookahead = 25.0; 
const scheduleAheadTime = 0.1;
let timerID: number | undefined;

// -- Music Data (4-Bar Loop) --
// Progression: I (C) -> IV (F) -> V (G) -> I (C)

const bassLine = [
  // Bar 1: C Major (Driving Root)
  N.C3, N._, N.C3, N._, N.C3, N._, N.C3, N._, N.G2, N._, N.G2, N._, N.C3, N._, N.E3, N._,
  // Bar 2: F Major (Subdominant lift)
  N.F2, N._, N.F2, N._, N.F2, N._, N.F2, N._, N.C3, N._, N.C3, N._, N.F2, N._, N.A2, N._,
  // Bar 3: G Major (Tension)
  N.G2, N._, N.G2, N._, N.G2, N._, N.G2, N._, N.D3, N._, N.D3, N._, N.G2, N._, N.B2, N._,
  // Bar 4: C Major Turnaround
  N.C3, N._, N.C3, N._, N.C3, N._, N.E3, N._, N.F3, N._, N.Fs3, N._, N.G3, N._, N.B2, N._
];

const leadLine = [
  // Bar 1: Heroic Theme (Arpeggio up)
  N.C5, N._, N.E5, N._, N.G5, N._, N.C6, N._, N.G5, N.E5, N.C5, N._, N.E5, N.G5, N.C6, N._,
  // Bar 2: Variation High (F Major)
  N.A5, N._, N.F5, N._, N.C6, N._, N.A5, N._, N.F5, N.A5, N.C6, N.A5, N.F6, N.E6, N.D6, N.C6,
  // Bar 3: Climbing (G Major)
  N.B5, N._, N.G5, N._, N.D6, N._, N.B5, N._, N.G5, N.B5, N.D6, N.B5, N.G6, N.F6, N.E6, N.D6,
  // Bar 4: Resolution Run
  N.C6, N._, N.G5, N._, N.E5, N._, N.C5, N._, N.D5, N.E5, N.F5, N.G5, N.A5, N.B5, N.C6, N._
];

export const initAudio = () => {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  
  if (!masterGainNode) {
    masterGainNode = audioCtx.createGain();
    masterGainNode.gain.value = isMuted ? 0 : 0.12; // Slightly lower master to prevent clipping
    masterGainNode.connect(audioCtx.destination);
  }

  startMusic();
};

export const startMusic = () => {
  if (!audioCtx || isMusicPlaying) return;
  isMusicPlaying = true;
  nextNoteTime = audioCtx.currentTime + 0.1;
  scheduler();
};

const nextNote = () => {
  const secondsPerBeat = 60.0 / tempo;
  nextNoteTime += 0.25 * secondsPerBeat; // Advance 1/16th note
  currentStep = (currentStep + 1) % SEQUENCE_LENGTH;
};

const playKick = (time: number) => {
  if (!audioCtx || !masterGainNode) return;
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  
  osc.connect(gain);
  gain.connect(masterGainNode);
  
  // Punchy Kick
  osc.frequency.setValueAtTime(150, time);
  osc.frequency.exponentialRampToValueAtTime(0.01, time + 0.5);
  
  gain.gain.setValueAtTime(0.8, time);
  gain.gain.exponentialRampToValueAtTime(0.01, time + 0.5);
  
  osc.start(time);
  osc.stop(time + 0.5);
};

const playSnare = (time: number) => {
  if (!audioCtx || !masterGainNode) return;
  
  // Noise buffer for retro snare
  const bufferSize = audioCtx.sampleRate * 0.1; 
  const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < bufferSize; i++) {
    data[i] = Math.random() * 2 - 1;
  }

  const noise = audioCtx.createBufferSource();
  noise.buffer = buffer;
  
  const noiseGain = audioCtx.createGain();
  noiseGain.connect(masterGainNode);
  
  // Snappy Envelope
  noiseGain.gain.setValueAtTime(0.3, time);
  noiseGain.gain.exponentialRampToValueAtTime(0.01, time + 0.08);
  
  noise.start(time);
};

const playSynthNote = (freq: number, time: number, duration: number, type: OscillatorType = 'square', vol: number = 0.1) => {
  if (!audioCtx || !masterGainNode || freq <= 0) return;
  
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  
  osc.type = type;
  osc.frequency.value = freq;
  
  osc.connect(gain);
  gain.connect(masterGainNode);
  
  // Staccato envelope for 8-bit feel
  gain.gain.setValueAtTime(vol, time);
  gain.gain.linearRampToValueAtTime(vol, time + duration * 0.5); // Sustain bit longer
  gain.gain.linearRampToValueAtTime(0, time + duration * 0.9);
  
  osc.start(time);
  osc.stop(time + duration);
};

const scheduleNote = (stepIndex: number, time: number) => {
  const noteDuration = (60 / tempo) * 0.25; // 16th note duration

  // 1. DRUMS (Standard 4/4 Rock Beat)
  // 16th notes per bar = 16. 
  // Kick on beats 1 and 3 (Steps 0, 8 in a 16-step bar)
  // Snare on beats 2 and 4 (Steps 4, 12 in a 16-step bar)
  
  const stepInBar = stepIndex % 16;
  
  if (stepInBar === 0 || stepInBar === 8) {
    playKick(time);
  }
  if (stepInBar === 4 || stepInBar === 12) {
    playSnare(time);
  }

  // 2. BASS (Square wave, lower octave)
  const bassFreq = bassLine[stepIndex];
  if (bassFreq > 0) {
    playSynthNote(bassFreq, time, noteDuration, 'square', 0.15);
  }

  // 3. LEAD (Pulse/Square, higher octave)
  const leadFreq = leadLine[stepIndex];
  if (leadFreq > 0) {
    // 50% pulse width effect simulated by using a different wave or gain trick? 
    // WebAudio basic oscillators don't do PWM easily. Square is fine.
    // Make lead slightly louder and shorter
    playSynthNote(leadFreq, time, noteDuration * 0.8, 'square', 0.08); 
  }
};

const scheduler = () => {
  while (nextNoteTime < audioCtx!.currentTime + scheduleAheadTime) {
    scheduleNote(currentStep, nextNoteTime);
    nextNote();
  }
  timerID = window.setTimeout(scheduler, lookahead);
};

export const toggleMute = () => {
  isMuted = !isMuted;
  if (masterGainNode && audioCtx) {
    const now = audioCtx.currentTime;
    masterGainNode.gain.cancelScheduledValues(now);
    masterGainNode.gain.linearRampToValueAtTime(isMuted ? 0 : 0.12, now + 0.5);
  }
  return isMuted;
};

// -- SFX Helpers --

const playTone = (freq: number, type: OscillatorType, duration: number, startTime: number, vol = 0.1) => {
  if (!audioCtx || isMuted) return;
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  
  osc.type = type;
  osc.frequency.setValueAtTime(freq, startTime);
  
  gain.gain.setValueAtTime(vol, startTime);
  gain.gain.exponentialRampToValueAtTime(0.01, startTime + duration);
  
  osc.connect(gain);
  gain.connect(audioCtx.destination);
  
  osc.start(startTime);
  osc.stop(startTime + duration);
};

export const playCorrectSound = () => {
  if (!audioCtx) initAudio();
  if (!audioCtx) return;
  const now = audioCtx.currentTime;
  // Coin sound: B5 -> E6
  playTone(987.77, 'square', 0.1, now, 0.1); 
  playTone(1318.51, 'square', 0.2, now + 0.08, 0.1);
};

export const playWrongSound = () => {
  if (!audioCtx) initAudio();
  if (!audioCtx) return;
  const now = audioCtx.currentTime;
  // Error buzz
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.type = 'sawtooth';
  osc.frequency.setValueAtTime(100, now);
  osc.frequency.linearRampToValueAtTime(50, now + 0.3);
  
  gain.gain.setValueAtTime(0.2, now);
  gain.gain.linearRampToValueAtTime(0, now + 0.3);
  
  osc.connect(gain);
  gain.connect(audioCtx.destination);
  osc.start(now);
  osc.stop(now + 0.3);
};

export const playVictorySound = () => {
  if (!audioCtx) initAudio();
  if (!audioCtx) return;
  const now = audioCtx.currentTime;
  
  // Epic Arcade Victory Fanfare
  // Rapid Arpeggios climbing up: C -> F -> G -> Final C Chord
  
  // 1. C Major Arp (Fast)
  playTone(N.C5, 'square', 0.08, now + 0.00, 0.1);
  playTone(N.E5, 'square', 0.08, now + 0.08, 0.1);
  playTone(N.G5, 'square', 0.08, now + 0.16, 0.1);
  
  // 2. F Major Arp (Fast)
  playTone(N.F5, 'square', 0.08, now + 0.24, 0.1);
  playTone(N.A5, 'square', 0.08, now + 0.32, 0.1);
  playTone(N.C6, 'square', 0.08, now + 0.40, 0.1);

  // 3. G Major Arp (Fast)
  playTone(N.G5, 'square', 0.08, now + 0.48, 0.1);
  playTone(N.B5, 'square', 0.08, now + 0.56, 0.1);
  playTone(N.D6, 'square', 0.08, now + 0.64, 0.1);

  // 4. Final Grand Chord (C Major - Sustained)
  const finalTime = now + 0.8;
  // Melody Note
  playTone(N.C6, 'square', 1.5, finalTime, 0.2); 
  // Harmony (Third)
  playTone(N.E6, 'triangle', 1.5, finalTime, 0.15); 
  // Root Bass
  playTone(N.C5, 'sawtooth', 1.5, finalTime, 0.2); 
  
  // Optional: Echo/Delay effect manually simulated
  playTone(N.C6, 'square', 1.0, finalTime + 0.15, 0.05);
};

export const playClickSound = () => {
  if (!audioCtx) initAudio();
  if (!audioCtx) return;
  playTone(440, 'triangle', 0.05, audioCtx.currentTime, 0.05);
};

export const playLiftoffSound = () => {
    if (!audioCtx) initAudio();
    if (!audioCtx || isMuted) return;
    const now = audioCtx.currentTime;

    // White Noise Slide Up (Rocket effect)
    const bufferSize = audioCtx.sampleRate * 1.0; 
    const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
    }
    const noise = audioCtx.createBufferSource();
    noise.buffer = buffer;
    
    // Lowpass filter to sweep up
    const filter = audioCtx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(100, now);
    filter.frequency.exponentialRampToValueAtTime(2000, now + 0.8);

    const gain = audioCtx.createGain();
    gain.gain.setValueAtTime(0.3, now);
    gain.gain.linearRampToValueAtTime(0, now + 0.8);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(audioCtx.destination);
    noise.start(now);

    // Rising Tone
    playTone(200, 'sawtooth', 0.8, now, 0.1);
    const osc = audioCtx.createOscillator();
    osc.frequency.setValueAtTime(200, now);
    osc.frequency.linearRampToValueAtTime(800, now + 0.8);
    const oscGain = audioCtx.createGain();
    oscGain.gain.setValueAtTime(0.1, now);
    oscGain.gain.linearRampToValueAtTime(0, now + 0.8);
    osc.connect(oscGain);
    oscGain.connect(audioCtx.destination);
    osc.start(now);
    osc.stop(now + 0.8);
};

export const playTimeoutSound = () => playWrongSound();

export const playGameOverSound = () => {
  if (!audioCtx) initAudio();
  if (!audioCtx) return;
  const now = audioCtx.currentTime;
  // Descending sad tones
  playTone(300, 'sawtooth', 0.3, now, 0.2);
  playTone(250, 'sawtooth', 0.3, now + 0.3, 0.2);
  playTone(200, 'sawtooth', 0.8, now + 0.6, 0.2);
};
